<?php


echo '
<!DOCTYPE html>
			<html>
				<head>
					<meta charset=\'UTF-8\'>
					<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
					<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
                    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" ></script>
                    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
                    <link rel="stylesheet" href="./css/boostrap-grid.css">
					<link rel="stylesheet" href="./css/bootstrap.min.css">
					<link rel="stylesheet" href="./css/bootstrap.css">
					<link rel="stylesheet" href="./css/style.css">
					<link rel="stylesheet" type="text/css" href="./css/table.css">



            </head>
            <body>






<div class="dropdown">
			<button class="btn btn-secondary btn-info dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
			  Filtre
			</button>
				<ul class="dropdown-menu">
			  		<li><a class="dropdown-item" href="#">Action</a></li>
			  		<li><a class="dropdown-item" href="#">Another action</a></li>
			  		<li><a class="dropdown-item" href="#">Something else here</a></li>
				</ul>
		  </div></br>
          </body>
          </html>
          
          ';
          


          ?>

